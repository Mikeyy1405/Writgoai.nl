import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { searchBolProducts } from "@/lib/bolcom";

export const dynamic = "force-dynamic";

// POST: Search bol.com products for a site
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const body = await request.json();
    const { siteId, searchTerm, page = 1, pageSize = 10 } = body;

    if (!siteId) {
      return NextResponse.json(
        { error: "Site ID is verplicht" },
        { status: 400 }
      );
    }

    if (!searchTerm || searchTerm.trim().length < 2) {
      return NextResponse.json(
        { error: "Zoekterm is verplicht (min 2 karakters)" },
        { status: 400 }
      );
    }

    // Get site with bol.com credentials
    const site = await prisma.site.findFirst({
      where: {
        id: siteId,
        userId: (session.user as any).id,
      },
      select: {
        bolClientId: true,
        bolClientSecret: true,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site niet gevonden" }, { status: 404 });
    }

    if (!site.bolClientId || !site.bolClientSecret) {
      return NextResponse.json(
        { error: "Bol.com API credentials niet geconfigureerd voor deze site" },
        { status: 400 }
      );
    }

    const result = await searchBolProducts(
      site.bolClientId,
      site.bolClientSecret,
      searchTerm.trim(),
      { page, pageSize }
    );

    return NextResponse.json(result);
  } catch (error: any) {
    console.error("Bol.com search error:", error);
    return NextResponse.json(
      { error: error.message || "Bol.com zoeken mislukt" },
      { status: 500 }
    );
  }
}
