import { NextRequest } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { fetchArticleImages, PixabayImage } from "@/lib/pixabay";

export const dynamic = "force-dynamic";

interface SitePage {
  id: string;
  title: string;
  slug: string;
  keywords: string | null;
}

interface AffiliateLink {
  id: string;
  productName: string;
  affiliateUrl: string;
  price: number | null;
  ean: string | null;
  imageUrl: string | null;
  source: string;
}

interface SiteData {
  domain: string;
  pages: SitePage[];
  affiliateLinks?: AffiliateLink[];
}

const ARTICLE_TYPE_PROMPTS: Record<string, string> = {
  koopgids: `Je schrijft een UITGEBREIDE "Beste [product] 2025" koopgids die direct publiceerbaar is.

VERPLICHTE STRUCTUUR:

## Introductie (150-200 woorden)
- Haak de lezer met een herkenbaar probleem of situatie
- Noem het hoofdkeyword in de eerste zin
- Geef een preview van wat ze gaan leren
- Vermeld hoeveel producten je gaat vergelijken

## Snel Antwoord / Onze Top 3 (direct na intro)
Geef meteen de top 3 met korte motivatie zodat snelle lezers direct antwoord hebben:
1. **[Productnaam]** - Beste keuze voor de meeste mensen - [AFFILIATE LINK]
2. **[Productnaam]** - Beste budget optie - [AFFILIATE LINK]  
3. **[Productnaam]** - Beste premium keuze - [AFFILIATE LINK]

## Vergelijkingstabel
Maak een complete tabel met deze kolommen:
| Product | Prijs | Belangrijkste Feature | Score | Kopen |
|---------|-------|----------------------|-------|-------|
| [Naam] | €XX | [Feature] | 9.2/10 | [AFFILIATE LINK] |

## Per Product Uitgebreide Review (200-300 woorden elk)
Voor ELK product in de tabel:
### [Productnaam] - [Korte USP]
- Opening: Voor wie is dit product?
- **Specificaties**: Noem 4-6 concrete specs (afmetingen, vermogen, materiaal, etc.)
- **Wat ons opviel**: 2-3 positieve ervaringspunten
- **Nadelen**: Wees eerlijk over 1-2 minpunten
- **Prijs-kwaliteit**: Geef concrete waarde-inschatting
- [KOOP BUTTON]

## Waar Let Je Op Bij Het Kopen?
Behandel 4-6 belangrijke aankoopfactoren met uitleg per factor.

## Veelgestelde Vragen
Beantwoord 4-5 relevante vragen die kopers hebben.

## Conclusie
- Herhaal de #1 aanbeveling met motivatie
- Geef alternatief voor specifieke situaties
- Sterke call-to-action`,

  review: `Je schrijft een DIEPGAANDE product review die direct publiceerbaar is.

VERPLICHTE STRUCTUUR:

## Verdict Samenvatting (boven aan artikel)
Geef direct een score en korte samenvatting:
**Score: X.X/10**
**In het kort:** [2-3 zinnen samenvatting]
**Beste voor:** [type gebruiker]
**Prijs:** €XX bij [winkel] [AFFILIATE LINK]

## Introductie (100-150 woorden)
- Waarom we dit product reviewen
- Wat is het en voor wie?
- Hoe lang hebben we het getest?

## Specificaties & Kenmerken
Maak een overzichtelijke specs tabel:
| Specificatie | Waarde |
|--------------|--------|
| Afmetingen | XX x XX cm |
| Gewicht | XX gram |
| [etc.] | [etc.] |

## Uitpakken & Eerste Indruk
Beschrijf de unboxing ervaring, meegeleverde accessoires, build quality.

## Prestaties in de Praktijk
Test het product in echte situaties. Wees SPECIFIEK:
- Niet: "Het werkt goed"
- Wel: "Na 2 weken dagelijks gebruik merkten we dat..."

## Voordelen
- [Concreet voordeel 1 met uitleg]
- [Concreet voordeel 2 met uitleg]
- [etc.]

## Nadelen
- [Eerlijk nadeel 1 met context]
- [Eerlijk nadeel 2 met context]

## Vergelijking met Alternatieven
Vergelijk kort met 2-3 concurrenten.

## Eindoordeel
- Score breakdown per categorie
- Voor wie wel/niet geschikt
- Finale aanbeveling met [KOOP BUTTON]`,

  vergelijking: `Je schrijft een COMPLETE vergelijkingsartikel dat direct publiceerbaar is.

VERPLICHTE STRUCTUUR:

## Introductie
- Waarom deze twee producten vergelijken?
- Voor wie is deze vergelijking relevant?
- Spoiler: geef een hint naar de conclusie

## Quick Verdict
**[Product A]** - Beste voor: [specifieke situatie]
**[Product B]** - Beste voor: [specifieke situatie]

## Specificaties Vergelijking
| Eigenschap | [Product A] | [Product B] | Winnaar |
|------------|-------------|-------------|---------|
| Prijs | €XX | €XX | [Naam] |
| [Feature 1] | [Waarde] | [Waarde] | [Naam] |
| [etc.] | | | |

## Gedetailleerde Vergelijking per Categorie

### Design & Bouwkwaliteit
[200+ woorden vergelijking]
**Winnaar:** [Product] omdat...

### Prestaties
[200+ woorden vergelijking]
**Winnaar:** [Product] omdat...

### Gebruiksgemak
[150+ woorden vergelijking]
**Winnaar:** [Product] omdat...

### Prijs-Kwaliteit
[150+ woorden vergelijking]
**Winnaar:** [Product] omdat...

## Score Overzicht
| Categorie | [Product A] | [Product B] |
|-----------|-------------|-------------|
| Design | X/10 | X/10 |
| [etc.] | | |
| **Totaal** | **X.X/10** | **X.X/10** |

## Conclusie: Welke Moet Je Kiezen?
- Kies [Product A] als je...
- Kies [Product B] als je...
[AFFILIATE LINK] voor beide producten`,

  howto: `Je schrijft een COMPLETE how-to guide die direct publiceerbaar is.

VERPLICHTE STRUCTUUR:

## Introductie
- Wat gaat de lezer leren?
- Waarom is dit belangrijk?
- Hoe lang duurt het? Wat is de moeilijkheidsgraad?

## Snel Antwoord
Geef direct het korte antwoord voor snelle lezers.

## Wat Heb Je Nodig?
Lijst met benodigdheden, tools, of voorwaarden.

## Stap-voor-Stap Instructies

### Stap 1: [Actie]
[Gedetailleerde uitleg, 100+ woorden]
💡 **Tip:** [Handige tip voor deze stap]

### Stap 2: [Actie]
[Gedetailleerde uitleg, 100+ woorden]
⚠️ **Let op:** [Waarschuwing indien relevant]

[Etc. voor alle stappen]

## Veelgemaakte Fouten
- **Fout 1:** [Beschrijving] → **Oplossing:** [Hoe te voorkomen]
- **Fout 2:** [Beschrijving] → **Oplossing:** [Hoe te voorkomen]

## Pro Tips
Extra tips voor gevorderde gebruikers.

## Veelgestelde Vragen
4-5 FAQ's gerelateerd aan het onderwerp.

## Samenvatting
Korte recap van de belangrijkste stappen.

## Aanbevolen Producten (indien relevant)
[Product aanbevelingen met AFFILIATE LINK]`,

  faq: `Je schrijft een UITGEBREID FAQ/informatief artikel dat direct publiceerbaar is.

VERPLICHTE STRUCTUUR:

## Direct Antwoord
Begin met het directe antwoord op de hoofdvraag in 2-3 zinnen.

## Uitgebreide Uitleg
Ga dieper in op het antwoord met context en nuance (300-400 woorden).

## Gerelateerde Vragen

### [Gerelateerde vraag 1]?
[Uitgebreid antwoord, 150-200 woorden]

### [Gerelateerde vraag 2]?
[Uitgebreid antwoord, 150-200 woorden]

### [Gerelateerde vraag 3]?
[Uitgebreid antwoord, 150-200 woorden]

### [Gerelateerde vraag 4]?
[Uitgebreid antwoord, 150-200 woorden]

## Praktische Tips
3-5 actionable tips gerelateerd aan het onderwerp.

## Samenvatting
Korte recap van de belangrijkste punten.

## Aanbevolen Producten/Diensten (indien relevant)
[Suggesties met AFFILIATE LINK indien passend]`,
};

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return new Response(JSON.stringify({ error: "Niet geautoriseerd" }), {
        status: 401,
        headers: { "Content-Type": "application/json" },
      });
    }

    const body = await request.json();
    const { keyword, articleType, extraContext, wordCount, siteId, siteData, includeImages } = body;

    if (!keyword) {
      return new Response(JSON.stringify({ error: "Keyword is verplicht" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    // Fetch images if requested
    let images: PixabayImage[] = [];
    if (includeImages) {
      try {
        images = await fetchArticleImages(keyword, articleType, 4);
      } catch (error) {
        console.error("Error fetching images:", error);
      }
    }

    // Build internal links section for the prompt
    let internalLinksSection = "";
    if (siteData && siteData.pages && siteData.pages.length > 0) {
      const pageList = siteData.pages
        .map((p: SitePage) => `- "${p.title}" → https://${siteData.domain}/${p.slug}${p.keywords ? ` (keywords: ${p.keywords})` : ""}`)
        .join("\n");
      
      internalLinksSection = `

AUTOMATISCHE CONTEXTUELE INTERNE LINKS (VERPLICHT):
Je hebt toegang tot ${siteData.pages.length} pagina's van de website ${siteData.domain}. 
Voeg AUTOMATISCH interne links toe door relevante woorden in de tekst te linken.

STRATEGIE VOOR CONTEXTUELE LINKS:
1. Scan de tekst op woorden/zinsdelen die overeenkomen met beschikbare pagina's
2. Link NATUURLIJK - de anchor text moet logisch in de zin passen
3. Gebruik GEEN "klik hier" of "lees meer" - link de relevante woorden zelf
4. Plaats 3-5 interne links verspreid door het artikel
5. Link niet dezelfde pagina meerdere keren

VOORBEELD VAN GOEDE CONTEXTUELE LINKING:
❌ Fout: "Wil je meer weten? Klik hier voor elektrische tandenborstels."
✅ Goed: "De [Oral-B iO Series 9](url) is een uitstekende keuze voor wie op zoek is naar [elektrische tandenborstels](url)."

BESCHIKBARE PAGINA'S:
${pageList}

LINKING REGELS:
- Als je schrijft over een onderwerp dat matcht met een pagina titel → link die woorden
- Als je een product/merk noemt dat in een pagina voorkomt → link het
- Keywords zijn hints voor welke woorden te linken
- Format: [anchor text](https://${siteData.domain}/slug)`;
    }

    // Build affiliate products section for the prompt
    let affiliateProductsSection = "";
    if (siteData && siteData.affiliateLinks && siteData.affiliateLinks.length > 0) {
      const productList = siteData.affiliateLinks
        .map((link: AffiliateLink) => {
          let productInfo = `- "${link.productName}"`;
          if (link.price) productInfo += ` (€${link.price.toFixed(2)})`;
          productInfo += ` → ${link.affiliateUrl}`;
          if (link.imageUrl) productInfo += ` [afbeelding: ${link.imageUrl}]`;
          return productInfo;
        })
        .join("\n");
      
      affiliateProductsSection = `

BESCHIKBARE AFFILIATE PRODUCTEN (GEBRUIK DEZE ECHTE LINKS):
Je hebt toegang tot ${siteData.affiliateLinks.length} affiliate producten met ECHTE affiliate links.
GEBRUIK DEZE PRODUCTEN EN LINKS IN JE ARTIKEL!

AFFILIATE PRODUCTEN DATABASE:
${productList}

INSTRUCTIES VOOR AFFILIATE LINKS:
1. Als je een product noemt dat in de database staat → gebruik de EXACTE affiliate URL
2. Vervang [AFFILIATE LINK] placeholders met de echte affiliate URLs uit de database
3. Gebruik de productafbeeldingen waar beschikbaar met format: ![productnaam](imageUrl)
4. Vermeld de prijs waar beschikbaar: "Nu verkrijgbaar voor €XX.XX"
5. Maak de links aantrekkelijk: "Bekijk op bol.com" of "Check huidige prijs"

VOORBEELD:
Als je schrijft over "Oral-B iO Series 9" en dit product staat in de database:
✅ "De [Oral-B iO Series 9](affiliate_url_uit_database) is momenteel te koop voor €299,99"
✅ ![Oral-B iO Series 9](image_url_uit_database)

BELANGRIJK:
- Geef PRIORITEIT aan producten uit de database - deze hebben werkende affiliate links
- Je mag ook andere producten noemen, maar gebruik dan [AFFILIATE LINK] placeholder
- De database producten zijn al gevalideerd en beschikbaar`;
    }

    // Build images section for the prompt
    let imagesSection = "";
    if (images.length > 0) {
      const imageList = images
        .map((img, i) => `[AFBEELDING ${i + 1}]: ${img.largeImageURL} (tags: ${img.tags})`)
        .join("\n");
      
      imagesSection = `

AFBEELDINGEN (VERPLICHT INVOEGEN):
Plaats de volgende afbeeldingen op logische plekken in het artikel. Gebruik markdown image syntax met een descriptieve alt-text.
Format: ![alt-text](url)

${imageList}

Plaats minimaal 2 afbeeldingen:
- 1 afbeelding direct na de introductie
- 1-2 afbeeldingen verspreid door het artikel bij relevante secties
- Schrijf een beschrijvende alt-text (niet "afbeelding 1")`;
    }

    const typePrompt = ARTICLE_TYPE_PROMPTS[articleType] || ARTICLE_TYPE_PROMPTS.koopgids;

    const systemPrompt = `Je bent een TOP Nederlandse affiliate content specialist met 10+ jaar ervaring in het schrijven van artikelen die RANKEN én CONVERTEREN.

JOUW SCHRIJFSTIJL:
- Je schrijft alsof je een goede vriend advies geeft - warm, behulpzaam, maar ook eerlijk
- Je bent een expert die écht verstand heeft van de producten
- Je gebruikt concrete voorbeelden en specifieke details (geen vage beweringen)
- Je schrijft vloeiend Nederlands - GEEN vertalingen uit het Engels
- Vermijd: "In deze gids...", "Laten we beginnen met...", "Het is belangrijk om te vermelden..."
- Gebruik WEL: Direct, actieve taal die de lezer aanspreekt

SEO REGELS (STRIKT VOLGEN):
1. Het keyword "${keyword}" moet voorkomen in:
   - De SEO titel (begin van de titel)
   - De eerste alinea (eerste 100 woorden)
   - Minimaal 2-3 H2 koppen
   - Natuurlijk verspreid door de tekst (keyword density ~1-2%)
2. Gebruik LSI keywords (verwante termen) door het hele artikel
3. Maak de content SCANBAAR: korte alinea's, bullet points, tabellen, vetgedrukte kernpunten

AFFILIATE CONVERSIE REGELS:
- Plaats [AFFILIATE LINK] na elke productvermelding
- Plaats [KOOP BUTTON] na elke productbespreking en in de conclusie
- Gebruik urgentie waar passend: "Op dit moment", "Actuele prijs", "Limited"
- Geef altijd concrete prijsindicaties (€XX - €XX)
- Noem specifieke webshops: bol.com, Coolblue, Amazon, MediaMarkt

CONTENT KWALITEIT:
- Minimaal ${wordCount} woorden
- ELKE bewering moet specifiek zijn (niet: "goede batterij" maar: "batterij gaat 8 uur mee")
- Noem ECHTE productnamen en modelnummers
- Wees eerlijk over nadelen - dit bouwt vertrouwen

FORMATTING:
- ## voor H2 koppen
- ### voor H3 koppen  
- | voor tabellen (ALTIJD met header row en separator)
- - voor bullet points
- **tekst** voor vetgedrukt

RESPONSE FORMAT (ALLEEN JSON, geen markdown code blocks):
{
  "seoTitle": "Keyword vooraan | Max 60 karakters | Jaar erin",
  "metaDescription": "Actieve zin met keyword + benefit + CTA | Max 155 karakters",
  "content": "Volledig artikel in markdown"
}${affiliateProductsSection}${internalLinksSection}${imagesSection}`;

    const userPrompt = `OPDRACHT: Schrijf een professioneel ${articleType} artikel over "${keyword}"

${typePrompt}

${extraContext ? `EXTRA CONTEXT VAN DE GEBRUIKER (verwerk dit in het artikel):
${extraContext}

` : ""}VEREISTEN:
- Minimaal ${wordCount} woorden
- Direct publiceerbaar op een Nederlandse affiliate website
- Alle genoemde producten moeten ECHT bestaan
- Prijzen moeten realistisch zijn voor de Nederlandse markt
- Focus op producten die via bol.com of Coolblue verkrijgbaar zijn`;

    const response = await fetch("https://apps.abacus.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.ABACUSAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        stream: true,
        max_tokens: 12000,
        temperature: 0.8,
        response_format: { type: "json_object" },
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("LLM API error:", errorText);
      return new Response(
        JSON.stringify({ error: "Content generatie mislukt" }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        const encoder = new TextEncoder();
        let buffer = "";
        let partialRead = "";

        if (!reader) {
          controller.error(new Error("No reader available"));
          return;
        }

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            partialRead += decoder.decode(value, { stream: true });
            const lines = partialRead.split("\n");
            partialRead = lines.pop() || "";

            for (const line of lines) {
              if (line.startsWith("data: ")) {
                const data = line.slice(6);
                if (data === "[DONE]") {
                  try {
                    // Clean the buffer - remove any markdown code blocks
                    let cleanBuffer = buffer.trim();
                    if (cleanBuffer.startsWith("```json")) {
                      cleanBuffer = cleanBuffer.slice(7);
                    }
                    if (cleanBuffer.startsWith("```")) {
                      cleanBuffer = cleanBuffer.slice(3);
                    }
                    if (cleanBuffer.endsWith("```")) {
                      cleanBuffer = cleanBuffer.slice(0, -3);
                    }
                    cleanBuffer = cleanBuffer.trim();

                    const finalResult = JSON.parse(cleanBuffer);

                    // Save to database
                    try {
                      await prisma.article.create({
                        data: {
                          userId: (session.user as any).id,
                          siteId: siteId || null,
                          keyword,
                          articleType,
                          extraContext: extraContext || null,
                          wordCount,
                          seoTitle: finalResult.seoTitle,
                          metaDescription: finalResult.metaDescription,
                          content: finalResult.content,
                        },
                      });
                    } catch (dbError) {
                      console.error("DB save error:", dbError);
                    }

                    // Add images to the result
                    const resultWithImages = {
                      ...finalResult,
                      images: images.length > 0 ? images : undefined,
                    };

                    const finalData = JSON.stringify({
                      status: "completed",
                      result: resultWithImages,
                    });
                    controller.enqueue(encoder.encode(`data: ${finalData}\n\n`));
                  } catch (parseError) {
                    console.error("Parse error:", parseError, "Buffer:", buffer);
                    controller.enqueue(
                      encoder.encode(
                        `data: ${JSON.stringify({
                          status: "error",
                          message: "JSON parsing mislukt",
                        })}\n\n`
                      )
                    );
                  }
                  controller.enqueue(encoder.encode("data: [DONE]\n\n"));
                  controller.close();
                  return;
                }

                try {
                  const parsed = JSON.parse(data);
                  const content = parsed.choices?.[0]?.delta?.content || "";
                  buffer += content;

                  // Send progress update
                  const progressData = JSON.stringify({
                    status: "processing",
                    message: "Genereren...",
                  });
                  controller.enqueue(encoder.encode(`data: ${progressData}\n\n`));
                } catch (e) {
                  // Skip invalid JSON chunks
                }
              }
            }
          }
        } catch (error) {
          console.error("Stream error:", error);
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({
                status: "error",
                message: "Stream error",
              })}\n\n`
            )
          );
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    });
  } catch (error) {
    console.error("Generate error:", error);
    return new Response(
      JSON.stringify({ error: "Er is een fout opgetreden" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}