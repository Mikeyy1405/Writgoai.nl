import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET: Fetch affiliate links for a site
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const siteId = searchParams.get("siteId");

    if (!siteId) {
      return NextResponse.json(
        { error: "Site ID is verplicht" },
        { status: 400 }
      );
    }

    // Verify ownership via site
    const site = await prisma.site.findFirst({
      where: {
        id: siteId,
        userId: (session.user as any).id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site niet gevonden" }, { status: 404 });
    }

    const links = await prisma.affiliateLink.findMany({
      where: { siteId },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(links);
  } catch (error) {
    console.error("Get affiliate links error:", error);
    return NextResponse.json(
      { error: "Ophalen affiliate links mislukt" },
      { status: 500 }
    );
  }
}

// POST: Create a new affiliate link
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const body = await request.json();
    const { siteId, productName, affiliateUrl, price, ean, imageUrl, source = "manual" } = body;

    if (!siteId || !productName || !affiliateUrl) {
      return NextResponse.json(
        { error: "Site ID, productnaam en affiliate URL zijn verplicht" },
        { status: 400 }
      );
    }

    // Verify ownership
    const site = await prisma.site.findFirst({
      where: {
        id: siteId,
        userId: (session.user as any).id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site niet gevonden" }, { status: 404 });
    }

    const link = await prisma.affiliateLink.create({
      data: {
        siteId,
        productName: productName.trim(),
        affiliateUrl: affiliateUrl.trim(),
        price: price ? parseFloat(price) : null,
        ean: ean?.trim() || null,
        imageUrl: imageUrl?.trim() || null,
        source,
      },
    });

    return NextResponse.json(link);
  } catch (error) {
    console.error("Create affiliate link error:", error);
    return NextResponse.json(
      { error: "Aanmaken affiliate link mislukt" },
      { status: 500 }
    );
  }
}

// DELETE: Delete an affiliate link
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const linkId = searchParams.get("id");

    if (!linkId) {
      return NextResponse.json(
        { error: "Link ID is verplicht" },
        { status: 400 }
      );
    }

    // Get link and verify ownership via site
    const link = await prisma.affiliateLink.findUnique({
      where: { id: linkId },
      include: {
        site: {
          select: { userId: true },
        },
      },
    });

    if (!link || link.site.userId !== (session.user as any).id) {
      return NextResponse.json(
        { error: "Affiliate link niet gevonden" },
        { status: 404 }
      );
    }

    await prisma.affiliateLink.delete({
      where: { id: linkId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete affiliate link error:", error);
    return NextResponse.json(
      { error: "Verwijderen affiliate link mislukt" },
      { status: 500 }
    );
  }
}
