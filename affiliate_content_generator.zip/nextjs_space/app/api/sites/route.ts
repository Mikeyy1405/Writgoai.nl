import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET: Fetch all sites for the user
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const sites = await prisma.site.findMany({
      where: { userId: (session.user as any).id },
      include: {
        pages: {
          orderBy: { title: "asc" },
        },
        affiliateLinks: {
          orderBy: { productName: "asc" },
        },
        _count: {
          select: { articles: true },
        },
      },
      orderBy: { name: "asc" },
    });

    // Add hasCredentials flag without exposing actual credentials
    const sitesWithFlags = sites.map(site => ({
      ...site,
      hasBolCredentials: !!site.bolClientId && !!site.bolClientSecret,
      bolClientId: undefined,
      bolClientSecret: undefined,
    }));

    return NextResponse.json(sitesWithFlags);
  } catch (error) {
    console.error("Get sites error:", error);
    return NextResponse.json({ error: "Ophalen sites mislukt" }, { status: 500 });
  }
}

// POST: Create a new site
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const body = await request.json();
    const { name, domain } = body;

    if (!name || !domain) {
      return NextResponse.json(
        { error: "Naam en domein zijn verplicht" },
        { status: 400 }
      );
    }

    // Normalize domain (remove protocol and trailing slash)
    const normalizedDomain = domain
      .replace(/^https?:\/\//, "")
      .replace(/\/$/, "")
      .toLowerCase();

    const site = await prisma.site.create({
      data: {
        userId: (session.user as any).id,
        name,
        domain: normalizedDomain,
      },
      include: {
        pages: true,
      },
    });

    return NextResponse.json(site);
  } catch (error) {
    console.error("Create site error:", error);
    return NextResponse.json({ error: "Aanmaken site mislukt" }, { status: 500 });
  }
}

// DELETE: Delete a site
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const siteId = searchParams.get("id");

    if (!siteId) {
      return NextResponse.json({ error: "Site ID is verplicht" }, { status: 400 });
    }

    // Verify ownership
    const site = await prisma.site.findFirst({
      where: {
        id: siteId,
        userId: (session.user as any).id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site niet gevonden" }, { status: 404 });
    }

    await prisma.site.delete({
      where: { id: siteId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete site error:", error);
    return NextResponse.json({ error: "Verwijderen site mislukt" }, { status: 500 });
  }
}
