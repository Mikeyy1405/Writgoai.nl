import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { fetchSitemap, generateKeywords } from "@/lib/sitemap";

export const dynamic = "force-dynamic";

// POST: Sync sitemap for a site
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const body = await request.json();
    const { siteId } = body;

    if (!siteId) {
      return NextResponse.json(
        { error: "Site ID is verplicht" },
        { status: 400 }
      );
    }

    // Verify ownership and get site
    const site = await prisma.site.findFirst({
      where: {
        id: siteId,
        userId: (session.user as any).id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site niet gevonden" }, { status: 404 });
    }

    // Fetch sitemap
    const result = await fetchSitemap(site.domain);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Sitemap ophalen mislukt" },
        { status: 400 }
      );
    }

    if (result.pages.length === 0) {
      return NextResponse.json(
        { error: "Geen pagina's gevonden in de sitemap" },
        { status: 400 }
      );
    }

    // Delete existing pages for this site
    await prisma.sitePage.deleteMany({
      where: { siteId: site.id },
    });

    // Create new pages from sitemap
    const pagesToCreate = result.pages.map((page) => ({
      siteId: site.id,
      title: page.title,
      slug: page.slug,
      keywords: generateKeywords(page.title),
    }));

    // Batch create (Prisma createMany)
    await prisma.sitePage.createMany({
      data: pagesToCreate,
    });

    // Fetch updated site with pages
    const updatedSite = await prisma.site.findUnique({
      where: { id: site.id },
      include: {
        pages: {
          orderBy: { title: "asc" },
        },
      },
    });

    return NextResponse.json({
      success: true,
      message: `${result.pages.length} pagina's geïmporteerd uit sitemap`,
      site: updatedSite,
      pagesImported: result.pages.length,
    });
  } catch (error) {
    console.error("Sitemap sync error:", error);
    return NextResponse.json(
      { error: "Sitemap synchronisatie mislukt" },
      { status: 500 }
    );
  }
}
