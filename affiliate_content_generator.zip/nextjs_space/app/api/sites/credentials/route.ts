import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";
import { validateBolCredentials } from "@/lib/bolcom";

export const dynamic = "force-dynamic";

// PUT: Update bol.com credentials for a site
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const body = await request.json();
    const { siteId, bolClientId, bolClientSecret } = body;

    if (!siteId) {
      return NextResponse.json(
        { error: "Site ID is verplicht" },
        { status: 400 }
      );
    }

    // Verify ownership
    const site = await prisma.site.findFirst({
      where: {
        id: siteId,
        userId: (session.user as any).id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site niet gevonden" }, { status: 404 });
    }

    // If credentials provided, validate them
    if (bolClientId && bolClientSecret) {
      const isValid = await validateBolCredentials(bolClientId, bolClientSecret);
      if (!isValid) {
        return NextResponse.json(
          { error: "Bol.com credentials zijn ongeldig. Controleer Client ID en Secret." },
          { status: 400 }
        );
      }
    }

    // Update credentials
    const updatedSite = await prisma.site.update({
      where: { id: siteId },
      data: {
        bolClientId: bolClientId || null,
        bolClientSecret: bolClientSecret || null,
      },
    });

    return NextResponse.json({
      success: true,
      hasCredentials: !!updatedSite.bolClientId && !!updatedSite.bolClientSecret,
    });
  } catch (error: any) {
    console.error("Update credentials error:", error);
    return NextResponse.json(
      { error: error.message || "Bijwerken credentials mislukt" },
      { status: 500 }
    );
  }
}
