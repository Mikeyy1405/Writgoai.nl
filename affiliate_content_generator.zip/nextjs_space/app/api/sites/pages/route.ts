import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

// POST: Add a page to a site
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const body = await request.json();
    const { siteId, title, slug, keywords } = body;

    if (!siteId || !title || !slug) {
      return NextResponse.json(
        { error: "Site ID, titel en slug zijn verplicht" },
        { status: 400 }
      );
    }

    // Verify site ownership
    const site = await prisma.site.findFirst({
      where: {
        id: siteId,
        userId: (session.user as any).id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site niet gevonden" }, { status: 404 });
    }

    // Normalize slug
    const normalizedSlug = slug
      .toLowerCase()
      .replace(/^\//, "") // Remove leading slash
      .replace(/\/$/, ""); // Remove trailing slash

    const page = await prisma.sitePage.create({
      data: {
        siteId,
        title,
        slug: normalizedSlug,
        keywords: keywords || null,
      },
    });

    return NextResponse.json(page);
  } catch (error) {
    console.error("Create page error:", error);
    return NextResponse.json({ error: "Aanmaken pagina mislukt" }, { status: 500 });
  }
}

// DELETE: Remove a page
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const pageId = searchParams.get("id");

    if (!pageId) {
      return NextResponse.json({ error: "Page ID is verplicht" }, { status: 400 });
    }

    // Verify ownership through site
    const page = await prisma.sitePage.findFirst({
      where: { id: pageId },
      include: { site: true },
    });

    if (!page || page.site.userId !== (session.user as any).id) {
      return NextResponse.json({ error: "Pagina niet gevonden" }, { status: 404 });
    }

    await prisma.sitePage.delete({
      where: { id: pageId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete page error:", error);
    return NextResponse.json({ error: "Verwijderen pagina mislukt" }, { status: 500 });
  }
}

// PUT: Update a page
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
    }

    const body = await request.json();
    const { id, title, slug, keywords } = body;

    if (!id) {
      return NextResponse.json({ error: "Page ID is verplicht" }, { status: 400 });
    }

    // Verify ownership through site
    const page = await prisma.sitePage.findFirst({
      where: { id },
      include: { site: true },
    });

    if (!page || page.site.userId !== (session.user as any).id) {
      return NextResponse.json({ error: "Pagina niet gevonden" }, { status: 404 });
    }

    const updatedPage = await prisma.sitePage.update({
      where: { id },
      data: {
        ...(title && { title }),
        ...(slug && { slug: slug.toLowerCase().replace(/^\//, "").replace(/\/$/, "") }),
        ...(keywords !== undefined && { keywords: keywords || null }),
      },
    });

    return NextResponse.json(updatedPage);
  } catch (error) {
    console.error("Update page error:", error);
    return NextResponse.json({ error: "Bijwerken pagina mislukt" }, { status: 500 });
  }
}
