import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { Header } from "@/components/header";
import { HistoryList } from "@/components/history-list";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function HistoryPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    redirect("/login");
  }

  const articles = await prisma.article.findMany({
    where: { userId: (session.user as any).id },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  const serializedArticles = articles.map((article: any) => ({
    ...article,
    createdAt: article.createdAt.toISOString(),
    updatedAt: article.updatedAt.toISOString(),
  }));

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background">
      <Header />
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Artikel Geschiedenis</h1>
          <p className="text-muted-foreground">
            Bekijk en hergebruik je eerder gegenereerde artikelen.
          </p>
        </div>
        <HistoryList articles={serializedArticles} />
      </main>
    </div>
  );
}
