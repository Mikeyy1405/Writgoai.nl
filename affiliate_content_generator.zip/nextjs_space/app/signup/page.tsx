import { SignupForm } from "@/components/auth/signup-form";
import { Sparkles } from "lucide-react";
import Link from "next/link";

export default function SignupPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-primary/5 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
            <Sparkles className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-purple-400 bg-clip-text text-transparent">
            Account Aanmaken
          </h1>
          <p className="text-muted-foreground mt-2">
            Start met het genereren van affiliate content
          </p>
        </div>
        <SignupForm />
        <p className="text-center text-sm text-muted-foreground mt-6">
          Al een account?{" "}
          <Link href="/login" className="text-primary hover:underline font-medium">
            Log hier in
          </Link>
        </p>
      </div>
    </div>
  );
}
