/**
 * Bol.com Marketing Catalog API Integration
 * Handles authentication and product searching via the Partner API
 */

export interface BolProduct {
  ean: string;
  title: string;
  description?: string;
  price: number;
  strikethroughPrice?: number;
  imageUrl?: string;
  affiliateUrl: string;
  rating?: number;
  deliveryDescription?: string;
  brand?: string;
}

export interface BolSearchResult {
  products: BolProduct[];
  totalResults: number;
  page: number;
  pageSize: number;
}

const BOL_LOGIN_URL = "https://login.bol.com/token?grant_type=client_credentials";
const BOL_API_BASE = "https://api.bol.com";

// Cache for access tokens per site
const tokenCache = new Map<string, { token: string; expiresAt: number }>();

/**
 * Get an access token from bol.com using client credentials
 */
async function getAccessToken(
  clientId: string,
  clientSecret: string
): Promise<string> {
  const cacheKey = `${clientId}`;
  const cached = tokenCache.get(cacheKey);
  
  // Return cached token if still valid (with 60s buffer)
  if (cached && cached.expiresAt > Date.now() + 60000) {
    return cached.token;
  }

  // Create Basic Auth header: base64(clientId:clientSecret)
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

  const response = await fetch(BOL_LOGIN_URL, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${credentials}`,
      'Accept': 'application/json',
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Bol.com auth error:', response.status, errorText);
    throw new Error(`Bol.com authenticatie mislukt: ${response.status}`);
  }

  const data = await response.json();
  const token = data.access_token;
  const expiresIn = data.expires_in || 299; // Default 5 minutes

  // Cache the token
  tokenCache.set(cacheKey, {
    token,
    expiresAt: Date.now() + (expiresIn * 1000),
  });

  return token;
}

/**
 * Search for products on bol.com
 */
export async function searchBolProducts(
  clientId: string,
  clientSecret: string,
  searchTerm: string,
  options: {
    page?: number;
    pageSize?: number;
    includeImage?: boolean;
    includeOffer?: boolean;
    includeRating?: boolean;
  } = {}
): Promise<BolSearchResult> {
  const {
    page = 1,
    pageSize = 10,
    includeImage = true,
    includeOffer = true,
    includeRating = true,
  } = options;

  const accessToken = await getAccessToken(clientId, clientSecret);

  const params = new URLSearchParams({
    'search-term': searchTerm,
    'page': page.toString(),
    'page-size': pageSize.toString(),
    'country-code': 'NL',
    'include-image': includeImage.toString(),
    'include-offer': includeOffer.toString(),
    'include-rating': includeRating.toString(),
  });

  const response = await fetch(
    `${BOL_API_BASE}/marketing/catalog/v1/products/search?${params}`,
    {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/json',
        'Accept-Language': 'nl',
      },
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Bol.com search error:', response.status, errorText);
    throw new Error(`Bol.com zoeken mislukt: ${response.status}`);
  }

  const data = await response.json();

  const products: BolProduct[] = (data.results || []).map((item: any) => {
    // Get best offer URL or construct one
    const offer = item.offer;
    const affiliateUrl = offer?.url || `https://www.bol.com/nl/nl/p/-/${item.ean}/`;

    // Get image URL - prefer larger rendition
    let imageUrl: string | undefined;
    if (item.mainImage) {
      imageUrl = item.mainImage.url;
    }

    return {
      ean: item.ean,
      title: item.title,
      description: item.shortDescription || item.description,
      price: offer?.price || 0,
      strikethroughPrice: offer?.strikethroughPrice,
      imageUrl,
      affiliateUrl,
      rating: item.rating?.averageRating,
      deliveryDescription: offer?.deliveryDescription,
      brand: item.brand,
    };
  });

  return {
    products,
    totalResults: data.totalResults || products.length,
    page: data.page || page,
    pageSize: data.pageSize || pageSize,
  };
}

/**
 * Get a single product by EAN
 */
export async function getBolProduct(
  clientId: string,
  clientSecret: string,
  ean: string
): Promise<BolProduct | null> {
  const accessToken = await getAccessToken(clientId, clientSecret);

  const params = new URLSearchParams({
    'country-code': 'NL',
    'include-image': 'true',
    'include-offer': 'true',
    'include-rating': 'true',
    'include-specifications': 'false',
  });

  const response = await fetch(
    `${BOL_API_BASE}/marketing/catalog/v1/products/${ean}?${params}`,
    {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/json',
        'Accept-Language': 'nl',
      },
    }
  );

  if (!response.ok) {
    if (response.status === 404) {
      return null;
    }
    throw new Error(`Bol.com product ophalen mislukt: ${response.status}`);
  }

  const item = await response.json();
  const offer = item.offer;
  const affiliateUrl = offer?.url || `https://www.bol.com/nl/nl/p/-/${item.ean}/`;

  let imageUrl: string | undefined;
  if (item.mainImage) {
    imageUrl = item.mainImage.url;
  }

  return {
    ean: item.ean,
    title: item.title,
    description: item.shortDescription || item.description,
    price: offer?.price || 0,
    strikethroughPrice: offer?.strikethroughPrice,
    imageUrl,
    affiliateUrl,
    rating: item.rating?.averageRating,
    deliveryDescription: offer?.deliveryDescription,
    brand: item.brand,
  };
}

/**
 * Get the best offer for a product (includes affiliate URL)
 */
export async function getBolProductBestOffer(
  clientId: string,
  clientSecret: string,
  ean: string
): Promise<{ url: string; price: number; deliveryDescription?: string } | null> {
  const accessToken = await getAccessToken(clientId, clientSecret);

  const params = new URLSearchParams({
    'country-code': 'NL',
    'include-seller': 'false',
  });

  const response = await fetch(
    `${BOL_API_BASE}/marketing/catalog/v1/products/${ean}/offers/best?${params}`,
    {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/json',
        'Accept-Language': 'nl',
      },
    }
  );

  if (!response.ok) {
    if (response.status === 404) {
      return null;
    }
    throw new Error(`Bol.com offer ophalen mislukt: ${response.status}`);
  }

  const offer = await response.json();

  return {
    url: offer.url,
    price: offer.price,
    deliveryDescription: offer.deliveryDescription,
  };
}

/**
 * Validate bol.com credentials by attempting to get a token
 */
export async function validateBolCredentials(
  clientId: string,
  clientSecret: string
): Promise<boolean> {
  try {
    await getAccessToken(clientId, clientSecret);
    return true;
  } catch {
    return false;
  }
}
