function getPixabayApiKey(): string {
  return process.env.PIXABAY_API_KEY || "";
}

export interface PixabayImage {
  id: number;
  webformatURL: string;
  largeImageURL: string;
  previewURL: string;
  tags: string;
  pageURL: string;
  user: string;
  imageWidth: number;
  imageHeight: number;
}

export interface PixabaySearchResult {
  total: number;
  totalHits: number;
  hits: PixabayImage[];
}

export async function searchPixabayImages(
  query: string,
  options: {
    lang?: string;
    imageType?: "all" | "photo" | "illustration" | "vector";
    orientation?: "all" | "horizontal" | "vertical";
    category?: string;
    perPage?: number;
    page?: number;
    safeSearch?: boolean;
  } = {}
): Promise<PixabaySearchResult | null> {
  const apiKey = getPixabayApiKey();
  if (!apiKey) {
    console.error("Pixabay API key not found");
    return null;
  }

  const {
    lang = "nl",
    imageType = "photo",
    orientation = "horizontal",
    perPage = 5,
    page = 1,
    safeSearch = true,
  } = options;

  const params = new URLSearchParams({
    key: apiKey,
    q: query,
    lang,
    image_type: imageType,
    orientation,
    per_page: String(perPage),
    page: String(page),
    safesearch: String(safeSearch),
  });

  try {
    const response = await fetch(
      `https://pixabay.com/api/?${params.toString()}`
    );

    if (!response.ok) {
      console.error("Pixabay API error:", response.status);
      return null;
    }

    const data = await response.json();
    return data as PixabaySearchResult;
  } catch (error) {
    console.error("Pixabay fetch error:", error);
    return null;
  }
}

// Generate search queries based on article topic
export function generateImageQueries(keyword: string, articleType: string): string[] {
  const queries: string[] = [];
  
  // Main keyword query
  queries.push(keyword);
  
  // Type-specific queries
  switch (articleType) {
    case "koopgids":
    case "review":
      queries.push(`${keyword} product`);
      queries.push(`${keyword} shopping`);
      break;
    case "vergelijking":
      queries.push(`${keyword} comparison`);
      queries.push(`choice decision`);
      break;
    case "howto":
      queries.push(`${keyword} guide`);
      queries.push(`hands tutorial`);
      break;
    case "faq":
      queries.push(`${keyword} question`);
      queries.push(`help information`);
      break;
  }
  
  return queries;
}

// Fetch multiple images for an article
export async function fetchArticleImages(
  keyword: string,
  articleType: string,
  count: number = 3
): Promise<PixabayImage[]> {
  const queries = generateImageQueries(keyword, articleType);
  const images: PixabayImage[] = [];
  const seenIds = new Set<number>();

  for (const query of queries) {
    if (images.length >= count) break;

    const result = await searchPixabayImages(query, {
      perPage: Math.min(5, count - images.length + 2),
      orientation: "horizontal",
    });

    if (result?.hits) {
      for (const hit of result.hits) {
        if (!seenIds.has(hit.id) && images.length < count) {
          seenIds.add(hit.id);
          images.push(hit);
        }
      }
    }
  }

  return images;
}
