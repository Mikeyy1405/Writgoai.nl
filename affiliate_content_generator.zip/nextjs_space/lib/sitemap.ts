/**
 * Sitemap Fetching and Parsing Utility
 * Fetches sitemap.xml from a domain and extracts page URLs with metadata
 */

export interface SitemapPage {
  url: string;
  slug: string;
  title: string;
  lastmod?: string;
  priority?: string;
}

export interface SitemapResult {
  success: boolean;
  pages: SitemapPage[];
  error?: string;
  totalFound: number;
}

/**
 * Extract a readable title from a URL slug
 */
function slugToTitle(slug: string): string {
  if (!slug || slug === '' || slug === '/') {
    return 'Home';
  }
  
  // Remove leading/trailing slashes and get last segment
  const cleanSlug = slug.replace(/^\/|\/$|/g, '');
  const segments = cleanSlug.split('/').filter(Boolean);
  const lastSegment = segments[segments.length - 1] || 'Home';
  
  // Convert slug to readable title
  return lastSegment
    .replace(/[-_]/g, ' ')
    .replace(/\.(html?|php|aspx?)$/i, '')
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

/**
 * Parse the slug from a full URL
 */
function extractSlug(url: string, domain: string): string {
  try {
    const urlObj = new URL(url);
    let slug = urlObj.pathname;
    
    // Remove leading slash
    slug = slug.replace(/^\//, '');
    
    // Remove trailing slash
    slug = slug.replace(/\/$/, '');
    
    // Remove common file extensions for cleaner slugs
    slug = slug.replace(/\.(html?|php|aspx?)$/i, '');
    
    return slug || '';
  } catch {
    return '';
  }
}

/**
 * Parse sitemap XML content
 */
function parseSitemapXml(xmlContent: string, domain: string): SitemapPage[] {
  const pages: SitemapPage[] = [];
  
  // Match all <url> blocks
  const urlRegex = /<url[^>]*>([\s\S]*?)<\/url>/gi;
  let urlMatch;
  
  while ((urlMatch = urlRegex.exec(xmlContent)) !== null) {
    const urlBlock = urlMatch[1];
    
    // Extract <loc>
    const locMatch = urlBlock.match(/<loc[^>]*>([^<]+)<\/loc>/i);
    if (!locMatch) continue;
    
    const fullUrl = locMatch[1].trim();
    const slug = extractSlug(fullUrl, domain);
    
    // Skip if it's an image, video, or asset URL
    if (/\.(jpg|jpeg|png|gif|webp|svg|mp4|mp3|pdf|zip|css|js)$/i.test(fullUrl)) {
      continue;
    }
    
    // Extract optional fields
    const lastmodMatch = urlBlock.match(/<lastmod[^>]*>([^<]+)<\/lastmod>/i);
    const priorityMatch = urlBlock.match(/<priority[^>]*>([^<]+)<\/priority>/i);
    
    const page: SitemapPage = {
      url: fullUrl,
      slug: slug,
      title: slugToTitle(slug),
      lastmod: lastmodMatch?.[1]?.trim(),
      priority: priorityMatch?.[1]?.trim(),
    };
    
    pages.push(page);
  }
  
  return pages;
}

/**
 * Parse sitemap index to find all sitemap URLs
 */
function parseSitemapIndex(xmlContent: string): string[] {
  const sitemapUrls: string[] = [];
  const sitemapRegex = /<sitemap[^>]*>[\s\S]*?<loc[^>]*>([^<]+)<\/loc>[\s\S]*?<\/sitemap>/gi;
  let match;
  
  while ((match = sitemapRegex.exec(xmlContent)) !== null) {
    sitemapUrls.push(match[1].trim());
  }
  
  return sitemapUrls;
}

/**
 * Check if content is a sitemap index
 */
function isSitemapIndex(xmlContent: string): boolean {
  return xmlContent.includes('<sitemapindex') || xmlContent.includes('</sitemapindex>');
}

/**
 * Fetch sitemap from a domain
 * Tries multiple common sitemap locations
 */
export async function fetchSitemap(domain: string): Promise<SitemapResult> {
  // Normalize domain
  const cleanDomain = domain
    .replace(/^https?:\/\//, '')
    .replace(/\/$/, '')
    .toLowerCase();
  
  const baseUrl = `https://${cleanDomain}`;
  
  // Common sitemap locations to try
  const sitemapUrls = [
    `${baseUrl}/sitemap.xml`,
    `${baseUrl}/sitemap_index.xml`,
    `${baseUrl}/sitemap-index.xml`,
    `${baseUrl}/post-sitemap.xml`,
    `${baseUrl}/page-sitemap.xml`,
    `${baseUrl}/wp-sitemap.xml`,
  ];
  
  let allPages: SitemapPage[] = [];
  let foundSitemap = false;
  let lastError = '';
  
  for (const sitemapUrl of sitemapUrls) {
    try {
      const response = await fetch(sitemapUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; SitemapBot/1.0)',
          'Accept': 'application/xml, text/xml, */*',
        },
        // 10 second timeout
        signal: AbortSignal.timeout(10000),
      });
      
      if (!response.ok) {
        continue;
      }
      
      const content = await response.text();
      
      // Check if this is valid XML with sitemap content
      if (!content.includes('<url') && !content.includes('<sitemap')) {
        continue;
      }
      
      foundSitemap = true;
      
      // Check if it's a sitemap index
      if (isSitemapIndex(content)) {
        const subSitemapUrls = parseSitemapIndex(content);
        
        // Fetch each sub-sitemap (limit to first 5 to avoid too many requests)
        for (const subUrl of subSitemapUrls.slice(0, 5)) {
          try {
            const subResponse = await fetch(subUrl, {
              headers: {
                'User-Agent': 'Mozilla/5.0 (compatible; SitemapBot/1.0)',
                'Accept': 'application/xml, text/xml, */*',
              },
              signal: AbortSignal.timeout(10000),
            });
            
            if (subResponse.ok) {
              const subContent = await subResponse.text();
              const subPages = parseSitemapXml(subContent, cleanDomain);
              allPages = [...allPages, ...subPages];
            }
          } catch (subError) {
            console.warn(`Failed to fetch sub-sitemap ${subUrl}:`, subError);
          }
        }
      } else {
        // Regular sitemap
        const pages = parseSitemapXml(content, cleanDomain);
        allPages = [...allPages, ...pages];
      }
      
      // If we found pages, we can stop
      if (allPages.length > 0) {
        break;
      }
    } catch (error: any) {
      lastError = error.message || 'Unknown error';
      continue;
    }
  }
  
  if (!foundSitemap) {
    return {
      success: false,
      pages: [],
      error: `Geen sitemap gevonden op ${cleanDomain}. Probeer: ${sitemapUrls[0]}`,
      totalFound: 0,
    };
  }
  
  // Remove duplicates based on slug
  const uniquePages = Array.from(
    new Map(allPages.map(p => [p.slug, p])).values()
  );
  
  // Sort by priority (if available) or alphabetically
  uniquePages.sort((a, b) => {
    if (a.priority && b.priority) {
      return parseFloat(b.priority) - parseFloat(a.priority);
    }
    return a.slug.localeCompare(b.slug);
  });
  
  return {
    success: true,
    pages: uniquePages,
    totalFound: uniquePages.length,
  };
}

/**
 * Generate keywords from title for better matching
 */
export function generateKeywords(title: string): string {
  // Remove common words and generate keyword variations
  const stopWords = ['de', 'het', 'een', 'van', 'voor', 'met', 'en', 'of', 'is', 'in', 'op', 'te', 'aan', 'bij', 'om', 'naar'];
  
  const words = title
    .toLowerCase()
    .split(/\s+/)
    .filter(word => word.length > 2 && !stopWords.includes(word));
  
  return words.join(', ');
}
