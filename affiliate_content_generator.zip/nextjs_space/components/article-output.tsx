"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Copy,
  Check,
  RefreshCw,
  FileDown,
  FileText,
  Tag,
  AlignLeft,
  Image as ImageIcon,
  ExternalLink,
} from "lucide-react";

interface PixabayImage {
  id: number;
  webformatURL: string;
  largeImageURL: string;
  previewURL: string;
  tags: string;
  user: string;
}

interface ArticleOutputProps {
  content: {
    seoTitle: string;
    metaDescription: string;
    content: string;
    images?: PixabayImage[];
  } | null;
  loading: boolean;
  onRegenerate: () => void;
}

export function ArticleOutput({ content, loading, onRegenerate }: ArticleOutputProps) {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = async (text: string, field: string) => {
    await navigator.clipboard.writeText(text ?? "");
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleExportMarkdown = () => {
    if (!content) return;

    const markdown = `# ${content?.seoTitle ?? ""}

**Meta Description:** ${content?.metaDescription ?? ""}

---

${content?.content ?? ""}`;

    const blob = new Blob([markdown], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(content?.seoTitle ?? "artikel").toLowerCase().replace(/\s+/g, "-").slice(0, 50)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!content && !loading) {
    return (
      <Card className="border-border/50 shadow-lg h-full min-h-[600px] flex items-center justify-center">
        <CardContent className="text-center">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
            <FileText className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Geen Artikel Gegenereerd</h3>
          <p className="text-muted-foreground text-sm max-w-xs">
            Vul de details in en klik op "Genereer Artikel" om te beginnen.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (loading && !content) {
    return (
      <Card className="border-border/50 shadow-lg h-full min-h-[600px] flex items-center justify-center">
        <CardContent className="text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <FileText className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Artikel Wordt Gegenereerd</h3>
          <p className="text-muted-foreground text-sm">
            Even geduld, de AI schrijft je artikel...
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 shadow-lg">
      <CardHeader className="border-b border-border/50">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            Gegenereerd Artikel
          </CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onRegenerate} disabled={loading}>
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Regenereer
            </Button>
            <Button variant="outline" size="sm" onClick={handleExportMarkdown}>
              <FileDown className="w-4 h-4 mr-2" />
              Export MD
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        {/* SEO Title */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm font-medium">
              <Tag className="w-4 h-4 text-primary" />
              SEO Title
            </label>
            <span className={`text-xs ${
              (content?.seoTitle?.length ?? 0) > 60 ? "text-destructive" : "text-muted-foreground"
            }`}>
              {content?.seoTitle?.length ?? 0}/60 karakters
            </span>
          </div>
          <div className="flex gap-2">
            <div className="flex-1 p-3 bg-muted/50 rounded-lg border border-border">
              <p className="font-medium text-blue-600 dark:text-blue-400">
                {content?.seoTitle ?? ""}
              </p>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => handleCopy(content?.seoTitle ?? "", "title")}
            >
              {copiedField === "title" ? (
                <Check className="w-4 h-4 text-green-500" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Meta Description */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm font-medium">
              <AlignLeft className="w-4 h-4 text-primary" />
              Meta Description
            </label>
            <span className={`text-xs ${
              (content?.metaDescription?.length ?? 0) > 155 ? "text-destructive" : "text-muted-foreground"
            }`}>
              {content?.metaDescription?.length ?? 0}/155 karakters
            </span>
          </div>
          <div className="flex gap-2">
            <div className="flex-1 p-3 bg-muted/50 rounded-lg border border-border">
              <p className="text-sm text-muted-foreground">
                {content?.metaDescription ?? ""}
              </p>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => handleCopy(content?.metaDescription ?? "", "meta")}
            >
              {copiedField === "meta" ? (
                <Check className="w-4 h-4 text-green-500" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Article Content */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm font-medium">
              <FileText className="w-4 h-4 text-primary" />
              Artikel Content
            </label>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleCopy(content?.content ?? "", "content")}
            >
              {copiedField === "content" ? (
                <>
                  <Check className="w-4 h-4 mr-2 text-green-500" />
                  Gekopieerd!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Kopieer Artikel
                </>
              )}
            </Button>
          </div>
          <div className="p-4 bg-muted/30 rounded-lg border border-border max-h-[500px] overflow-y-auto">
            <div
              className="prose prose-sm dark:prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: formatContent(content?.content ?? "") }}
            />
          </div>
        </div>

        {/* Images Section */}
        {content?.images && content.images.length > 0 && (
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium">
              <ImageIcon className="w-4 h-4 text-primary" />
              Beschikbare Afbeeldingen ({content.images.length})
            </label>
            <p className="text-xs text-muted-foreground mb-2">
              Deze afbeeldingen zijn in het artikel geplaatst. Je kunt de URLs ook direct kopiëren.
            </p>
            <div className="grid grid-cols-2 gap-3">
              {content.images.map((img, index) => (
                <div
                  key={img.id}
                  className="relative group rounded-lg overflow-hidden border border-border bg-muted/30"
                >
                  <div className="aspect-video relative">
                    <img
                      src={img.webformatURL}
                      alt={img.tags}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="p-2 space-y-1">
                    <p className="text-xs text-muted-foreground truncate">
                      {img.tags}
                    </p>
                    <div className="flex gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs flex-1"
                        onClick={() => handleCopy(img.largeImageURL, `img-${index}`)}
                      >
                        {copiedField === `img-${index}` ? (
                          <Check className="w-3 h-3 mr-1 text-green-500" />
                        ) : (
                          <Copy className="w-3 h-3 mr-1" />
                        )}
                        URL
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs"
                        onClick={() => window.open(img.largeImageURL, "_blank")}
                      >
                        <ExternalLink className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <div className="absolute top-1 right-1 bg-black/60 text-white text-xs px-1.5 py-0.5 rounded">
                    {index + 1}
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              📷 Afbeeldingen van Pixabay • Vrij te gebruiken
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function formatContent(content: string): string {
  if (!content) return "";
  
  // Convert markdown-like syntax to HTML
  let html = content
    // Images - handle markdown images: ![alt](url)
    .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<figure class="my-4"><img src="$2" alt="$1" class="w-full rounded-lg shadow-md" loading="lazy" /><figcaption class="text-xs text-muted-foreground text-center mt-2">$1</figcaption></figure>')
    // Links - handle markdown links: [text](url)
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="text-primary hover:underline" target="_blank" rel="noopener noreferrer">$1</a>')
    // Headers
    .replace(/^### (.*)$/gm, "<h3>$1</h3>")
    .replace(/^## (.*)$/gm, "<h2>$1</h2>")
    .replace(/^# (.*)$/gm, "<h1>$1</h1>")
    // Bold
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    // Italic
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    // Bullet points
    .replace(/^- (.*)$/gm, "<li>$1</li>")
    .replace(/^\* (.*)$/gm, "<li>$1</li>")
    // Numbered lists
    .replace(/^\d+\. (.*)$/gm, "<li>$1</li>")
    // Links placeholder styling
    .replace(/\[AFFILIATE LINK\]/g, '<span class="inline-block px-2 py-1 bg-primary/20 text-primary rounded text-xs font-mono">[AFFILIATE LINK]</span>')
    .replace(/\[KOOP BUTTON\]/g, '<span class="inline-block px-3 py-1 bg-green-500/20 text-green-600 dark:text-green-400 rounded text-xs font-mono">[KOOP BUTTON]</span>')
    // Internal link placeholder styling
    .replace(/\[INTERNE LINK: ([^\]]+)\]/g, '<span class="inline-block px-2 py-1 bg-blue-500/20 text-blue-600 dark:text-blue-400 rounded text-xs font-mono">[INTERNE LINK: $1]</span>')
    // Tables (basic)
    .replace(/\|(.+)\|/g, (match) => {
      const cells = match.split("|").filter(Boolean).map(cell => cell.trim());
      return `<tr>${cells.map(cell => `<td class="border border-border px-3 py-2">${cell}</td>`).join("")}</tr>`;
    })
    // Line breaks
    .replace(/\n\n/g, "</p><p>")
    .replace(/\n/g, "<br/>");

  // Wrap in paragraph if not starting with HTML tag
  if (!html.startsWith("<")) {
    html = `<p>${html}</p>`;
  }

  // Wrap consecutive li elements in ul
  html = html.replace(/(<li>.*?<\/li>)+/g, "<ul class='list-disc pl-6 my-4 space-y-1'>$&</ul>");

  return html;
}
