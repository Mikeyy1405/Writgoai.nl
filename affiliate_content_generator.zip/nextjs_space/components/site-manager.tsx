"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Globe,
  Plus,
  Trash2,
  Link2,
  Settings,
  Loader2,
  X,
  RefreshCw,
  FileDown,
  CheckCircle2,
  AlertCircle,
  Key,
  Search,
  ShoppingBag,
  ExternalLink,
  Star,
  Image as ImageIcon,
} from "lucide-react";

export interface AffiliateLink {
  id: string;
  siteId: string;
  productName: string;
  affiliateUrl: string;
  price: number | null;
  ean: string | null;
  imageUrl: string | null;
  source: string;
}

export interface SitePage {
  id: string;
  siteId: string;
  title: string;
  slug: string;
  keywords: string | null;
}

export interface Site {
  id: string;
  name: string;
  domain: string;
  pages: SitePage[];
  affiliateLinks: AffiliateLink[];
  hasBolCredentials?: boolean;
  _count?: { articles: number };
}

interface BolProduct {
  ean: string;
  title: string;
  price: number;
  imageUrl?: string;
  affiliateUrl: string;
  rating?: number;
}

interface SiteManagerProps {
  selectedSiteId: string | null;
  onSiteChange: (siteId: string | null) => void;
  onSitesLoaded?: (sites: Site[]) => void;
}

export function SiteManager({
  selectedSiteId,
  onSiteChange,
  onSitesLoaded,
}: SiteManagerProps) {
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);
  const [addSiteOpen, setAddSiteOpen] = useState(false);
  const [manageOpen, setManageOpen] = useState(false);
  const [newSiteName, setNewSiteName] = useState("");
  const [newSiteDomain, setNewSiteDomain] = useState("");
  const [addingSite, setAddingSite] = useState(false);

  // Page form state
  const [addPageSiteId, setAddPageSiteId] = useState<string | null>(null);
  const [newPageTitle, setNewPageTitle] = useState("");
  const [newPageSlug, setNewPageSlug] = useState("");
  const [newPageKeywords, setNewPageKeywords] = useState("");
  const [addingPage, setAddingPage] = useState(false);

  // Sitemap sync state
  const [syncingSitemap, setSyncingSitemap] = useState<string | null>(null);
  const [sitemapMessage, setSitemapMessage] = useState<{ siteId: string; type: 'success' | 'error'; message: string } | null>(null);

  // Bol.com credentials state
  const [credentialsSiteId, setCredentialsSiteId] = useState<string | null>(null);
  const [bolClientId, setBolClientId] = useState("");
  const [bolClientSecret, setBolClientSecret] = useState("");
  const [savingCredentials, setSavingCredentials] = useState(false);
  const [credentialsMessage, setCredentialsMessage] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Affiliate links state
  const [addLinkSiteId, setAddLinkSiteId] = useState<string | null>(null);
  const [newLinkName, setNewLinkName] = useState("");
  const [newLinkUrl, setNewLinkUrl] = useState("");
  const [newLinkPrice, setNewLinkPrice] = useState("");
  const [addingLink, setAddingLink] = useState(false);

  // Bol.com search state
  const [searchSiteId, setSearchSiteId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<BolProduct[]>([]);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [addingProduct, setAddingProduct] = useState<string | null>(null);

  const fetchSites = async () => {
    try {
      const response = await fetch("/api/sites");
      if (response.ok) {
        const data = await response.json();
        setSites(data);
        onSitesLoaded?.(data);
      }
    } catch (error) {
      console.error("Error fetching sites:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSites();
  }, []);

  const handleAddSite = async () => {
    if (!newSiteName.trim() || !newSiteDomain.trim()) return;

    setAddingSite(true);
    try {
      const response = await fetch("/api/sites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newSiteName.trim(),
          domain: newSiteDomain.trim(),
        }),
      });

      if (response.ok) {
        await fetchSites();
        setNewSiteName("");
        setNewSiteDomain("");
        setAddSiteOpen(false);
      }
    } catch (error) {
      console.error("Error adding site:", error);
    } finally {
      setAddingSite(false);
    }
  };

  const handleDeleteSite = async (siteId: string) => {
    if (!confirm("Weet je zeker dat je deze site wilt verwijderen? Alle pagina's en affiliate links worden ook verwijderd.")) {
      return;
    }

    try {
      const response = await fetch(`/api/sites?id=${siteId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        if (selectedSiteId === siteId) {
          onSiteChange(null);
        }
        await fetchSites();
      }
    } catch (error) {
      console.error("Error deleting site:", error);
    }
  };

  const handleAddPage = async () => {
    if (!addPageSiteId || !newPageTitle.trim() || !newPageSlug.trim()) return;

    setAddingPage(true);
    try {
      const response = await fetch("/api/sites/pages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          siteId: addPageSiteId,
          title: newPageTitle.trim(),
          slug: newPageSlug.trim(),
          keywords: newPageKeywords.trim() || null,
        }),
      });

      if (response.ok) {
        await fetchSites();
        setNewPageTitle("");
        setNewPageSlug("");
        setNewPageKeywords("");
        setAddPageSiteId(null);
      }
    } catch (error) {
      console.error("Error adding page:", error);
    } finally {
      setAddingPage(false);
    }
  };

  const handleDeletePage = async (pageId: string) => {
    try {
      const response = await fetch(`/api/sites/pages?id=${pageId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchSites();
      }
    } catch (error) {
      console.error("Error deleting page:", error);
    }
  };

  const handleSyncSitemap = async (siteId: string) => {
    setSyncingSitemap(siteId);
    setSitemapMessage(null);
    
    try {
      const response = await fetch("/api/sites/sitemap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ siteId }),
      });

      const data = await response.json();

      if (response.ok) {
        await fetchSites();
        setSitemapMessage({
          siteId,
          type: 'success',
          message: data.message || `${data.pagesImported} pagina's geïmporteerd`,
        });
      } else {
        setSitemapMessage({
          siteId,
          type: 'error',
          message: data.error || 'Sitemap ophalen mislukt',
        });
      }
    } catch (error) {
      console.error("Error syncing sitemap:", error);
      setSitemapMessage({
        siteId,
        type: 'error',
        message: 'Netwerk fout bij ophalen sitemap',
      });
    } finally {
      setSyncingSitemap(null);
    }
  };

  const handleSaveCredentials = async (siteId: string) => {
    setSavingCredentials(true);
    setCredentialsMessage(null);

    try {
      const response = await fetch("/api/sites/credentials", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          siteId,
          bolClientId: bolClientId.trim() || null,
          bolClientSecret: bolClientSecret.trim() || null,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        await fetchSites();
        setCredentialsMessage({
          type: 'success',
          message: 'Bol.com credentials opgeslagen!',
        });
        setBolClientId("");
        setBolClientSecret("");
        setCredentialsSiteId(null);
      } else {
        setCredentialsMessage({
          type: 'error',
          message: data.error || 'Opslaan credentials mislukt',
        });
      }
    } catch (error) {
      setCredentialsMessage({
        type: 'error',
        message: 'Netwerk fout bij opslaan credentials',
      });
    } finally {
      setSavingCredentials(false);
    }
  };

  const handleAddAffiliateLink = async () => {
    if (!addLinkSiteId || !newLinkName.trim() || !newLinkUrl.trim()) return;

    setAddingLink(true);
    try {
      const response = await fetch("/api/sites/affiliate-links", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          siteId: addLinkSiteId,
          productName: newLinkName.trim(),
          affiliateUrl: newLinkUrl.trim(),
          price: newLinkPrice ? parseFloat(newLinkPrice) : null,
          source: "manual",
        }),
      });

      if (response.ok) {
        await fetchSites();
        setNewLinkName("");
        setNewLinkUrl("");
        setNewLinkPrice("");
        setAddLinkSiteId(null);
      }
    } catch (error) {
      console.error("Error adding affiliate link:", error);
    } finally {
      setAddingLink(false);
    }
  };

  const handleDeleteAffiliateLink = async (linkId: string) => {
    try {
      const response = await fetch(`/api/sites/affiliate-links?id=${linkId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchSites();
      }
    } catch (error) {
      console.error("Error deleting affiliate link:", error);
    }
  };

  const handleSearchBol = async (siteId: string) => {
    if (!searchTerm.trim()) return;

    setSearching(true);
    setSearchError(null);
    setSearchResults([]);

    try {
      const response = await fetch("/api/bolcom/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          siteId,
          searchTerm: searchTerm.trim(),
          pageSize: 10,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setSearchResults(data.products || []);
        if (data.products?.length === 0) {
          setSearchError("Geen producten gevonden");
        }
      } else {
        setSearchError(data.error || "Zoeken mislukt");
      }
    } catch (error) {
      setSearchError("Netwerk fout bij zoeken");
    } finally {
      setSearching(false);
    }
  };

  const handleAddBolProduct = async (siteId: string, product: BolProduct) => {
    setAddingProduct(product.ean);

    try {
      const response = await fetch("/api/sites/affiliate-links", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          siteId,
          productName: product.title,
          affiliateUrl: product.affiliateUrl,
          price: product.price,
          ean: product.ean,
          imageUrl: product.imageUrl,
          source: "bolcom",
        }),
      });

      if (response.ok) {
        await fetchSites();
        // Remove from search results
        setSearchResults(prev => prev.filter(p => p.ean !== product.ean));
      }
    } catch (error) {
      console.error("Error adding bol.com product:", error);
    } finally {
      setAddingProduct(null);
    }
  };

  const selectedSite = sites.find((s) => s.id === selectedSiteId);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium flex items-center gap-2">
          <Globe className="w-4 h-4 text-primary" />
          Website & Affiliate Links
        </Label>
        <Dialog open={manageOpen} onOpenChange={setManageOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 px-2">
              <Settings className="w-4 h-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-primary" />
                Beheer Websites, Pagina's & Affiliate Links
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4 pt-4">
              {/* Add Site Form */}
              <div className="p-4 border rounded-lg bg-muted/30">
                <h4 className="font-medium mb-3 flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Nieuwe Website Toevoegen
                </h4>
                <div className="grid gap-3">
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      placeholder="Naam (bijv. Elektrische Tandenborstel Expert)"
                      value={newSiteName}
                      onChange={(e) => setNewSiteName(e.target.value)}
                    />
                    <Input
                      placeholder="Domein (bijv. elektrischetandenborstelexpert.nl)"
                      value={newSiteDomain}
                      onChange={(e) => setNewSiteDomain(e.target.value)}
                    />
                  </div>
                  <Button
                    onClick={handleAddSite}
                    disabled={addingSite || !newSiteName.trim() || !newSiteDomain.trim()}
                    className="w-full"
                  >
                    {addingSite ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <Plus className="w-4 h-4 mr-2" />
                    )}
                    Website Toevoegen
                  </Button>
                </div>
              </div>

              {/* Sites List */}
              {sites.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Geen websites toegevoegd. Voeg je eerste website toe om te beginnen.
                </p>
              ) : (
                <Accordion type="single" collapsible className="space-y-2">
                  {sites.map((site) => (
                    <AccordionItem
                      key={site.id}
                      value={site.id}
                      className="border rounded-lg px-4"
                    >
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-center gap-3 text-left">
                          <Globe className="w-4 h-4 text-primary" />
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-medium">{site.name}</p>
                              {site.hasBolCredentials && (
                                <span className="text-[10px] bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400 px-1.5 py-0.5 rounded">
                                  bol.com ✓
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {site.domain} • {site.pages.length} pagina's • {site.affiliateLinks?.length || 0} producten
                            </p>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pt-4 pb-2">
                        <Tabs defaultValue="pages" className="w-full">
                          <TabsList className="grid w-full grid-cols-3">
                            <TabsTrigger value="pages" className="text-xs">
                              <Link2 className="w-3 h-3 mr-1" />
                              Pagina's
                            </TabsTrigger>
                            <TabsTrigger value="products" className="text-xs">
                              <ShoppingBag className="w-3 h-3 mr-1" />
                              Producten
                            </TabsTrigger>
                            <TabsTrigger value="bolcom" className="text-xs">
                              <Key className="w-3 h-3 mr-1" />
                              Bol.com API
                            </TabsTrigger>
                          </TabsList>

                          {/* Pages Tab */}
                          <TabsContent value="pages" className="space-y-3 mt-4">
                            {/* Sitemap Sync */}
                            <div className="p-3 border rounded-lg bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30">
                              <div className="flex items-center gap-2 mb-2">
                                <FileDown className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                                <span className="text-sm font-medium">Sitemap Synchronisatie</span>
                              </div>
                              <p className="text-xs text-muted-foreground mb-2">
                                Haal automatisch alle pagina's op uit de sitemap.xml
                              </p>
                              <Button
                                variant="outline"
                                size="sm"
                                className="w-full bg-white dark:bg-gray-900"
                                onClick={() => handleSyncSitemap(site.id)}
                                disabled={syncingSitemap === site.id}
                              >
                                {syncingSitemap === site.id ? (
                                  <><RefreshCw className="w-3 h-3 mr-2 animate-spin" /> Ophalen...</>
                                ) : (
                                  <><RefreshCw className="w-3 h-3 mr-2" /> Sitemap Ophalen</>
                                )}
                              </Button>
                              {sitemapMessage && sitemapMessage.siteId === site.id && (
                                <div className={`mt-2 p-2 rounded text-xs flex items-center gap-2 ${
                                  sitemapMessage.type === 'success' 
                                    ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
                                    : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                                }`}>
                                  {sitemapMessage.type === 'success' ? <CheckCircle2 className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                                  {sitemapMessage.message}
                                </div>
                              )}
                            </div>

                            {/* Pages List */}
                            <div className="space-y-2">
                              <span className="text-sm font-medium text-muted-foreground">
                                Pagina's ({site.pages.length})
                              </span>
                              {site.pages.length === 0 ? (
                                <p className="text-sm text-muted-foreground py-2">
                                  Nog geen pagina's. Gebruik "Sitemap Ophalen" of voeg handmatig toe.
                                </p>
                              ) : (
                                <div className="max-h-[200px] overflow-y-auto space-y-1 pr-1">
                                  {site.pages.map((page) => (
                                    <div key={page.id} className="flex items-center justify-between p-2 bg-muted/50 rounded text-sm">
                                      <div className="flex items-center gap-2 min-w-0 flex-1">
                                        <Link2 className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                                        <div className="min-w-0">
                                          <p className="font-medium truncate">{page.title}</p>
                                          <p className="text-xs text-muted-foreground truncate">/{page.slug}</p>
                                        </div>
                                      </div>
                                      <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-destructive" onClick={() => handleDeletePage(page.id)}>
                                        <X className="w-3 h-3" />
                                      </Button>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Add Page Form */}
                            {addPageSiteId === site.id ? (
                              <div className="space-y-2 p-3 border rounded bg-background">
                                <p className="text-xs font-medium">Handmatig toevoegen</p>
                                <Input placeholder="Pagina titel" value={newPageTitle} onChange={(e) => setNewPageTitle(e.target.value)} />
                                <Input placeholder="Slug (bijv. beste-producten)" value={newPageSlug} onChange={(e) => setNewPageSlug(e.target.value)} />
                                <Input placeholder="Keywords (optioneel)" value={newPageKeywords} onChange={(e) => setNewPageKeywords(e.target.value)} />
                                <div className="flex gap-2">
                                  <Button size="sm" onClick={handleAddPage} disabled={addingPage || !newPageTitle.trim() || !newPageSlug.trim()}>
                                    {addingPage && <Loader2 className="w-3 h-3 animate-spin mr-1" />}
                                    Toevoegen
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={() => { setAddPageSiteId(null); setNewPageTitle(""); setNewPageSlug(""); setNewPageKeywords(""); }}>
                                    Annuleren
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <Button variant="outline" size="sm" className="w-full" onClick={() => setAddPageSiteId(site.id)}>
                                <Plus className="w-3 h-3 mr-1" /> Handmatig Toevoegen
                              </Button>
                            )}
                          </TabsContent>

                          {/* Products/Affiliate Links Tab */}
                          <TabsContent value="products" className="space-y-3 mt-4">
                            {/* Existing Affiliate Links */}
                            <div className="space-y-2">
                              <span className="text-sm font-medium text-muted-foreground">
                                Affiliate Producten ({site.affiliateLinks?.length || 0})
                              </span>
                              {(!site.affiliateLinks || site.affiliateLinks.length === 0) ? (
                                <p className="text-sm text-muted-foreground py-2">
                                  Nog geen producten. Voeg handmatig toe of zoek via bol.com.
                                </p>
                              ) : (
                                <div className="max-h-[250px] overflow-y-auto space-y-1 pr-1">
                                  {site.affiliateLinks.map((link) => (
                                    <div key={link.id} className="flex items-center gap-2 p-2 bg-muted/50 rounded text-sm">
                                      {link.imageUrl ? (
                                        <img src={link.imageUrl} alt="" className="w-10 h-10 object-contain rounded bg-white" />
                                      ) : (
                                        <div className="w-10 h-10 bg-muted rounded flex items-center justify-center">
                                          <ImageIcon className="w-4 h-4 text-muted-foreground" />
                                        </div>
                                      )}
                                      <div className="flex-1 min-w-0">
                                        <p className="font-medium truncate">{link.productName}</p>
                                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                          {link.price && <span className="text-green-600 dark:text-green-400 font-medium">€{link.price.toFixed(2)}</span>}
                                          <span className={`px-1 rounded ${link.source === 'bolcom' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400' : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'}`}>
                                            {link.source === 'bolcom' ? 'bol.com' : 'handmatig'}
                                          </span>
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-1">
                                        <a href={link.affiliateUrl} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary">
                                          <ExternalLink className="w-3 h-3" />
                                        </a>
                                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-destructive" onClick={() => handleDeleteAffiliateLink(link.id)}>
                                          <X className="w-3 h-3" />
                                        </Button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Add Manual Affiliate Link */}
                            {addLinkSiteId === site.id ? (
                              <div className="space-y-2 p-3 border rounded bg-background">
                                <p className="text-xs font-medium">Handmatig toevoegen</p>
                                <Input placeholder="Productnaam" value={newLinkName} onChange={(e) => setNewLinkName(e.target.value)} />
                                <Input placeholder="Affiliate URL" value={newLinkUrl} onChange={(e) => setNewLinkUrl(e.target.value)} />
                                <Input placeholder="Prijs (optioneel, bijv. 49.99)" type="number" step="0.01" value={newLinkPrice} onChange={(e) => setNewLinkPrice(e.target.value)} />
                                <div className="flex gap-2">
                                  <Button size="sm" onClick={handleAddAffiliateLink} disabled={addingLink || !newLinkName.trim() || !newLinkUrl.trim()}>
                                    {addingLink && <Loader2 className="w-3 h-3 animate-spin mr-1" />}
                                    Toevoegen
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={() => { setAddLinkSiteId(null); setNewLinkName(""); setNewLinkUrl(""); setNewLinkPrice(""); }}>
                                    Annuleren
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <Button variant="outline" size="sm" className="w-full" onClick={() => setAddLinkSiteId(site.id)}>
                                <Plus className="w-3 h-3 mr-1" /> Handmatig Product Toevoegen
                              </Button>
                            )}

                            {/* Bol.com Search */}
                            {site.hasBolCredentials && (
                              <div className="p-3 border rounded-lg bg-gradient-to-r from-orange-50 to-yellow-50 dark:from-orange-950/30 dark:to-yellow-950/30">
                                <div className="flex items-center gap-2 mb-2">
                                  <Search className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                                  <span className="text-sm font-medium">Zoek op Bol.com</span>
                                </div>
                                <div className="flex gap-2">
                                  <Input
                                    placeholder="Zoek product (bijv. elektrische tandenborstel)"
                                    value={searchSiteId === site.id ? searchTerm : ""}
                                    onChange={(e) => { setSearchSiteId(site.id); setSearchTerm(e.target.value); }}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSearchBol(site.id)}
                                    className="flex-1"
                                  />
                                  <Button
                                    size="sm"
                                    onClick={() => handleSearchBol(site.id)}
                                    disabled={searching || !searchTerm.trim()}
                                  >
                                    {searching && searchSiteId === site.id ? (
                                      <Loader2 className="w-4 h-4 animate-spin" />
                                    ) : (
                                      <Search className="w-4 h-4" />
                                    )}
                                  </Button>
                                </div>

                                {searchError && searchSiteId === site.id && (
                                  <p className="text-xs text-red-600 dark:text-red-400 mt-2">{searchError}</p>
                                )}

                                {searchResults.length > 0 && searchSiteId === site.id && (
                                  <div className="mt-3 max-h-[300px] overflow-y-auto space-y-2">
                                    {searchResults.map((product) => (
                                      <div key={product.ean} className="flex items-center gap-2 p-2 bg-white dark:bg-gray-900 rounded border">
                                        {product.imageUrl ? (
                                          <img src={product.imageUrl} alt="" className="w-12 h-12 object-contain rounded" />
                                        ) : (
                                          <div className="w-12 h-12 bg-muted rounded flex items-center justify-center">
                                            <ImageIcon className="w-5 h-5 text-muted-foreground" />
                                          </div>
                                        )}
                                        <div className="flex-1 min-w-0">
                                          <p className="text-sm font-medium line-clamp-2">{product.title}</p>
                                          <div className="flex items-center gap-2 text-xs">
                                            <span className="text-green-600 dark:text-green-400 font-medium">€{product.price.toFixed(2)}</span>
                                            {product.rating && (
                                              <span className="flex items-center gap-0.5 text-yellow-600">
                                                <Star className="w-3 h-3 fill-current" />
                                                {product.rating.toFixed(1)}
                                              </span>
                                            )}
                                          </div>
                                        </div>
                                        <Button
                                          size="sm"
                                          onClick={() => handleAddBolProduct(site.id, product)}
                                          disabled={addingProduct === product.ean}
                                        >
                                          {addingProduct === product.ean ? (
                                            <Loader2 className="w-3 h-3 animate-spin" />
                                          ) : (
                                            <Plus className="w-3 h-3" />
                                          )}
                                        </Button>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )}
                          </TabsContent>

                          {/* Bol.com API Tab */}
                          <TabsContent value="bolcom" className="space-y-3 mt-4">
                            <div className="p-3 border rounded-lg bg-gradient-to-r from-orange-50 to-yellow-50 dark:from-orange-950/30 dark:to-yellow-950/30">
                              <div className="flex items-center gap-2 mb-2">
                                <Key className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                                <span className="text-sm font-medium">Bol.com Partner API</span>
                                {site.hasBolCredentials && (
                                  <span className="text-xs bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 px-1.5 py-0.5 rounded">
                                    Geconfigureerd ✓
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground mb-3">
                                Koppel je bol.com Partner API om producten te zoeken en affiliate links te genereren.
                                <a href="https://partner.bol.com" target="_blank" rel="noopener noreferrer" className="text-primary ml-1 underline">
                                  Credentials ophalen
                                </a>
                              </p>

                              {credentialsSiteId === site.id ? (
                                <div className="space-y-2">
                                  <Input
                                    placeholder="Client ID"
                                    value={bolClientId}
                                    onChange={(e) => setBolClientId(e.target.value)}
                                  />
                                  <Input
                                    type="password"
                                    placeholder="Client Secret"
                                    value={bolClientSecret}
                                    onChange={(e) => setBolClientSecret(e.target.value)}
                                  />
                                  {credentialsMessage && (
                                    <div className={`p-2 rounded text-xs flex items-center gap-2 ${
                                      credentialsMessage.type === 'success'
                                        ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                                        : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                                    }`}>
                                      {credentialsMessage.type === 'success' ? <CheckCircle2 className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                                      {credentialsMessage.message}
                                    </div>
                                  )}
                                  <div className="flex gap-2">
                                    <Button
                                      size="sm"
                                      onClick={() => handleSaveCredentials(site.id)}
                                      disabled={savingCredentials}
                                    >
                                      {savingCredentials ? (
                                        <Loader2 className="w-3 h-3 animate-spin mr-1" />
                                      ) : (
                                        <CheckCircle2 className="w-3 h-3 mr-1" />
                                      )}
                                      Opslaan & Valideren
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => {
                                        setCredentialsSiteId(null);
                                        setBolClientId("");
                                        setBolClientSecret("");
                                        setCredentialsMessage(null);
                                      }}
                                    >
                                      Annuleren
                                    </Button>
                                  </div>
                                </div>
                              ) : (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="w-full bg-white dark:bg-gray-900"
                                  onClick={() => setCredentialsSiteId(site.id)}
                                >
                                  <Key className="w-3 h-3 mr-2" />
                                  {site.hasBolCredentials ? 'Credentials Wijzigen' : 'Credentials Toevoegen'}
                                </Button>
                              )}
                            </div>
                          </TabsContent>
                        </Tabs>

                        {/* Delete Site */}
                        <div className="mt-4 pt-4 border-t">
                          <Button variant="destructive" size="sm" className="w-full" onClick={() => handleDeleteSite(site.id)}>
                            <Trash2 className="w-3 h-3 mr-1" /> Website Verwijderen
                          </Button>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Select
        value={selectedSiteId || "none"}
        onValueChange={(value) => onSiteChange(value === "none" ? null : value)}
      >
        <SelectTrigger>
          <SelectValue placeholder="Selecteer een website (optioneel)" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="none">Geen website</SelectItem>
          {sites.map((site) => (
            <SelectItem key={site.id} value={site.id}>
              {site.name} ({site.pages.length} pagina's, {site.affiliateLinks?.length || 0} producten)
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {selectedSite && (
        <div className="text-xs text-muted-foreground space-y-0.5">
          {selectedSite.pages.length > 0 && (
            <p>✓ {selectedSite.pages.length} pagina's voor interne links</p>
          )}
          {(selectedSite.affiliateLinks?.length || 0) > 0 && (
            <p>✓ {selectedSite.affiliateLinks?.length} producten voor affiliate links</p>
          )}
          {selectedSite.pages.length === 0 && (selectedSite.affiliateLinks?.length || 0) === 0 && (
            <p className="text-amber-600 dark:text-amber-400">Voeg pagina's of producten toe aan deze site</p>
          )}
        </div>
      )}
    </div>
  );
}
