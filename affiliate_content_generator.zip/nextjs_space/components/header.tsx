"use client";

import { useSession, signOut } from "next-auth/react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Sparkles, Moon, Sun, LogOut, History } from "lucide-react";
import Link from "next/link";

export function Header() {
  const { data: session } = useSession() || {};
  const { theme, setTheme } = useTheme();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/dashboard" className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-primary/10">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <span className="font-bold text-lg hidden sm:inline">Content Generator</span>
        </Link>

        <div className="flex items-center gap-2">
          <Link href="/history">
            <Button variant="ghost" size="sm">
              <History className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Geschiedenis</span>
            </Button>
          </Link>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>

          {session?.user && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => signOut({ callbackUrl: "/login" })}
            >
              <LogOut className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Uitloggen</span>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
