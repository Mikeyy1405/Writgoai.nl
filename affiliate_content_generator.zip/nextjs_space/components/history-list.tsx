"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  FileText,
  ShoppingCart,
  GitCompare,
  HelpCircle,
  BookOpen,
  Calendar,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  Tag,
} from "lucide-react";

interface Article {
  id: string;
  keyword: string;
  articleType: string;
  seoTitle: string | null;
  metaDescription: string | null;
  content: string | null;
  wordCount: number;
  createdAt: string;
}

interface HistoryListProps {
  articles: Article[];
}

const TYPE_ICONS: Record<string, any> = {
  koopgids: ShoppingCart,
  review: FileText,
  vergelijking: GitCompare,
  howto: BookOpen,
  faq: HelpCircle,
};

const TYPE_LABELS: Record<string, string> = {
  koopgids: "Koopgids",
  review: "Review",
  vergelijking: "Vergelijking",
  howto: "How-to",
  faq: "FAQ",
};

export function HistoryList({ articles }: HistoryListProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = async (text: string, fieldId: string) => {
    await navigator.clipboard.writeText(text ?? "");
    setCopiedField(fieldId);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("nl-NL", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (!articles || articles.length === 0) {
    return (
      <Card className="border-border/50 shadow-lg">
        <CardContent className="py-12 text-center">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
            <FileText className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Geen Artikelen Gevonden</h3>
          <p className="text-muted-foreground text-sm">
            Je hebt nog geen artikelen gegenereerd. Ga naar het dashboard om te beginnen.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {articles.map((article) => {
        const Icon = TYPE_ICONS[article?.articleType ?? ""] || FileText;
        const isExpanded = expandedId === article?.id;

        return (
          <Card
            key={article?.id}
            className="border-border/50 shadow-lg hover:shadow-xl transition-shadow"
          >
            <CardHeader
              className="cursor-pointer"
              onClick={() => setExpandedId(isExpanded ? null : (article?.id ?? null))}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">
                      {article?.seoTitle || article?.keyword || "Untitled"}
                    </CardTitle>
                    <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Tag className="w-3 h-3" />
                        {TYPE_LABELS[article?.articleType ?? ""] || article?.articleType}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatDate(article?.createdAt ?? "")}
                      </span>
                      <span>{article?.wordCount ?? 0} woorden</span>
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="icon">
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5" />
                  ) : (
                    <ChevronDown className="w-5 h-5" />
                  )}
                </Button>
              </div>
            </CardHeader>

            {isExpanded && (
              <CardContent className="space-y-4 border-t border-border/50 pt-4">
                {/* Meta Description */}
                {article?.metaDescription && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Meta Description</label>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCopy(article.metaDescription ?? "", `meta-${article.id}`);
                        }}
                      >
                        {copiedField === `meta-${article.id}` ? (
                          <><Check className="w-3 h-3 mr-1 text-green-500" /> Gekopieerd</>
                        ) : (
                          <><Copy className="w-3 h-3 mr-1" /> Kopieer</>
                        )}
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded-lg">
                      {article.metaDescription}
                    </p>
                  </div>
                )}

                {/* Content Preview */}
                {article?.content && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Artikel Content</label>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCopy(article.content ?? "", `content-${article.id}`);
                        }}
                      >
                        {copiedField === `content-${article.id}` ? (
                          <><Check className="w-3 h-3 mr-1 text-green-500" /> Gekopieerd</>
                        ) : (
                          <><Copy className="w-3 h-3 mr-1" /> Kopieer Artikel</>
                        )}
                      </Button>
                    </div>
                    <div className="bg-muted/30 p-4 rounded-lg max-h-[300px] overflow-y-auto">
                      <pre className="text-sm whitespace-pre-wrap font-sans">
                        {article.content}
                      </pre>
                    </div>
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        );
      })}
    </div>
  );
}
