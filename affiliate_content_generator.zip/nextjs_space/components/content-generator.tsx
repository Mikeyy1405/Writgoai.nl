"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { ArticleOutput } from "@/components/article-output";
import { SiteManager, Site } from "@/components/site-manager";
import {
  Sparkles,
  Loader2,
  FileText,
  ShoppingCart,
  GitCompare,
  HelpCircle,
  BookOpen,
  Image as ImageIcon,
} from "lucide-react";

const ARTICLE_TYPES = [
  { value: "koopgids", label: "Koopgids", icon: ShoppingCart, description: "Beste [product] 2025 style" },
  { value: "review", label: "Product Review", icon: FileText, description: "Individuele product review" },
  { value: "vergelijking", label: "Vergelijking", icon: GitCompare, description: "[Product A] vs [Product B]" },
  { value: "howto", label: "How-to Guide", icon: BookOpen, description: "Informatief artikel" },
  { value: "faq", label: "FAQ/Long-tail", icon: HelpCircle, description: "Specifieke vragen" },
];

interface PixabayImage {
  id: number;
  webformatURL: string;
  largeImageURL: string;
  previewURL: string;
  tags: string;
  user: string;
}

interface GeneratedContent {
  seoTitle: string;
  metaDescription: string;
  content: string;
  images?: PixabayImage[];
}

export function ContentGenerator() {
  const [keyword, setKeyword] = useState("");
  const [articleType, setArticleType] = useState("koopgids");
  const [extraContext, setExtraContext] = useState("");
  const [wordCount, setWordCount] = useState([1500]);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [error, setError] = useState("");
  
  // New features
  const [selectedSiteId, setSelectedSiteId] = useState<string | null>(null);
  const [sites, setSites] = useState<Site[]>([]);
  const [includeImages, setIncludeImages] = useState(true);

  const handleGenerate = async () => {
    if (!keyword.trim()) {
      setError("Vul een keyword of onderwerp in");
      return;
    }

    setError("");
    setLoading(true);
    setProgress(0);
    setGeneratedContent(null);

    // Get selected site data for internal links and affiliate products
    const selectedSite = sites.find((s) => s.id === selectedSiteId);
    
    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          keyword: keyword.trim(),
          articleType,
          extraContext: extraContext.trim(),
          wordCount: wordCount[0],
          siteId: selectedSiteId,
          siteData: selectedSite ? {
            domain: selectedSite.domain,
            pages: selectedSite.pages,
            affiliateLinks: selectedSite.affiliateLinks,
          } : null,
          includeImages,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData?.error || "Generatie mislukt");
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let partialRead = "";

      if (!reader) {
        throw new Error("Geen response stream beschikbaar");
      }

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        partialRead += decoder.decode(value, { stream: true });
        const lines = partialRead.split("\n");
        partialRead = lines.pop() || "";

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const data = line.slice(6);
            if (data === "[DONE]") {
              return;
            }
            try {
              const parsed = JSON.parse(data);
              if (parsed.status === "processing") {
                setProgress((prev) => Math.min(prev + 2, 95));
              } else if (parsed.status === "completed") {
                setGeneratedContent(parsed.result);
                setProgress(100);
                return;
              } else if (parsed.status === "error") {
                throw new Error(parsed.message || "Generatie mislukt");
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (err: any) {
      console.error("Generate error:", err);
      setError(err?.message || "Er is een fout opgetreden bij het genereren");
    } finally {
      setLoading(false);
    }
  };

  const handleRegenerate = () => {
    handleGenerate();
  };

  return (
    <div className="grid lg:grid-cols-5 gap-6">
      {/* Input Section */}
      <div className="lg:col-span-2 space-y-6">
        <Card className="border-border/50 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              Artikel Generator
            </CardTitle>
            <CardDescription>
              Vul de details in en genereer je artikel
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Keyword Input */}
            <div className="space-y-2">
              <Label htmlFor="keyword" className="text-sm font-medium">
                Keyword / Onderwerp <span className="text-destructive">*</span>
              </Label>
              <Input
                id="keyword"
                placeholder="bijv. elektrische tandenborstel, beste laptops 2025"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                className="h-11"
              />
            </div>

            {/* Article Type Selection */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Artikel Type</Label>
              <div className="grid gap-2">
                {ARTICLE_TYPES.map((type) => {
                  const Icon = type.icon;
                  return (
                    <button
                      key={type.value}
                      type="button"
                      onClick={() => setArticleType(type.value)}
                      className={`flex items-center gap-3 p-3 rounded-lg border transition-all text-left ${
                        articleType === type.value
                          ? "border-primary bg-primary/10 shadow-sm"
                          : "border-border hover:border-primary/50 hover:bg-muted/50"
                      }`}
                    >
                      <Icon className={`w-5 h-5 ${articleType === type.value ? "text-primary" : "text-muted-foreground"}`} />
                      <div>
                        <p className="font-medium text-sm">{type.label}</p>
                        <p className="text-xs text-muted-foreground">{type.description}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Extra Context */}
            <div className="space-y-2">
              <Label htmlFor="context" className="text-sm font-medium">
                Extra Context <span className="text-muted-foreground">(optioneel)</span>
              </Label>
              <Textarea
                id="context"
                placeholder="Productdetails, USPs, prijzen, specifieke kenmerken..."
                value={extraContext}
                onChange={(e) => setExtraContext(e.target.value)}
                className="min-h-[100px] resize-none"
              />
            </div>

            {/* Word Count Slider */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Label className="text-sm font-medium">Woordenaantal</Label>
                <span className="text-sm font-semibold text-primary">
                  {wordCount[0]} woorden
                </span>
              </div>
              <Slider
                value={wordCount}
                onValueChange={setWordCount}
                min={500}
                max={3000}
                step={100}
                className="py-2"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>500</span>
                <span>1500</span>
                <span>3000</span>
              </div>
            </div>

            {/* Site Selection for Internal Links */}
            <SiteManager
              selectedSiteId={selectedSiteId}
              onSiteChange={setSelectedSiteId}
              onSitesLoaded={setSites}
            />

            {/* Include Images Toggle */}
            <div className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/30">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-primary" />
                <div>
                  <Label htmlFor="include-images" className="text-sm font-medium cursor-pointer">
                    Afbeeldingen Toevoegen
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Haal relevante afbeeldingen op via Pixabay
                  </p>
                </div>
              </div>
              <Switch
                id="include-images"
                checked={includeImages}
                onCheckedChange={setIncludeImages}
              />
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
                {error}
              </div>
            )}

            {/* Generate Button */}
            <Button
              onClick={handleGenerate}
              disabled={loading || !keyword.trim()}
              className="w-full h-12 text-base font-semibold"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Genereren... {progress}%
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Genereer Artikel
                </>
              )}
            </Button>

            {/* Progress Bar */}
            {loading && (
              <div className="space-y-2">
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all duration-300 rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-xs text-muted-foreground text-center">
                  AI genereert je artikel...
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Output Section */}
      <div className="lg:col-span-3">
        <ArticleOutput
          content={generatedContent}
          loading={loading}
          onRegenerate={handleRegenerate}
        />
      </div>
    </div>
  );
}
